<?php
use App\Post;
use App\User;
/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/', function () {
    return view('welcome');
});

// Route::get('/posts/{id}', 'postController@index');

// Route::resource('posts','postController');

// Route::get('/posts','postController@show_my_view');
// Route::get('/posts/{id}','postController@get_my_id');
// Route::get('/posts/{id}/{name}/{password}','postController@get_my_details');
// Route::get('/contact','postController@contact');
// Route::get('/test','postController@test');

// |--------------------------------------------------------------------------
// | Raw sql Queries
// |--------------------------------------------------------------------------
// Route::get('/insert',function(){
// 	DB::insert('insert into posts(title,content) values(?,?)',["title4","this is a test for the title 4"]);
// });

// Route::get('/read', function(){
// 	$result = DB::select('SELECT * FROM posts where id=?',[2]);
// 	// print_r($result);
// 	foreach ($result as $post) 
// 	{
// 		return $post->content;
// 	}
// });

// Route::get('/read_all', function(){
// 	$result = DB::select('SELECT * FROM posts');
// 	// print_r($result);
// 	foreach ($result as $post) 
// 	{
// 		echo $post->title."<br>";
// 	}
// });

// Route::get('/update',function(){
// 	$updated = DB::update('Update posts set title="updated title1" where id=?',[1]);

// 	return $updated;
// });

// Route::get('/delete', function(){
// 	$deleted = DB::delete('DELETE FROM posts WHERE id=?',[2]);
// 	return $deleted;
// });
// |--------------------------------------------------------------------------
// | Eloquent
// |--------------------------------------------------------------------------
// Route::get('/read_all',function(){
// 	$results = Post::all();
// 	foreach ($results as $r) 
// 	{
// 		echo $r->title."<br>";
// 		echo $r->content."<br><br>";

// 	}
// 	// print_r($results);
// });

// Route::get('/read',function(){
// 	$results = Post::find(5);

// 	echo $results->content;
// });

// Route::get('/read',function(){
// 	$results = Post::where('id',5)->orderBy('id','desc')->take(1)->get();

// 	foreach ($results as $res) {
// 		echo $res->title."<br>";
// 		echo $res->content."<br>";
// 	}
// });

// Route::get('/findmore',function(){
// 	$results = Post::findOrFail(2);
// 	return $results;
// });

// Route::get('/basicinsert',function(){
// 	$posts = new Post();
// 	$posts->title = "title 4";
// 	$posts->content = "this is content of title 4";

// 	$posts->save();
// });

// Route::get('/basicinsert2',function(){
// 	$posts = Post::findOrFail(3);

// 	$posts->title = "title 3";
// 	$posts->content = "this is content for title 3";

// 	$posts->save();
// });

// Route::get('/create',function(){
// 	Post::create(['title'=>"title 7", 'content'=>"this is a content for title 7"]);
// });

// Route::get('/update', function(){
// 	Post::where('id',8)->where('is_admin',0)->update(['title'=>"title 8",'content'=>"this is content for title 8"]);
// });

// Route::get('/delete', function(){
// 	// $posts = Post::find(4);
// 	// $posts->delete();

// 	// Post::destroy([6,7]);

// 	Post::where('id',8)->delete();
// });

// Route::get('/softdeletes',function(){
// 	$result = Post::find(5);

// 	$result->delete();

// });

// |--------------------------------------------------------------------------
// | Eloquent: relationships
// |--------------------------------------------------------------------------

Route::get('user/{id}/post',function($id){
	//return all posts
	return User::find($id)->posts;
	// return User::find($id)->posts->title;
	// return User::find($id)->posts->content;

});