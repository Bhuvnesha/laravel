@extends('layout/app')

@section('content')
<h1>This is contact page</h1>
@if(count($names) > 0)

	@foreach($names as $name)
		{{$name}}
	@endforeach

@endif


@endsection

