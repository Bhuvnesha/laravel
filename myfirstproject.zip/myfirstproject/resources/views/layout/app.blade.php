<html>
<head>
	<meta charset="UTF-8">
	<title>Testing Layout</title>
</head>
<body>
	<div class="container">
		@yield('content')

		@yield('footer')
	</div>
	
</body>
</html>