@extends('layout/app')

@section('content')
            <?php if(isset($id)) { ?>
            <h1>this is my posts.{{$id}}</h1>
            <?php } ?>
            <?php
                if(isset($id) AND isset($name) AND isset($password)) { ?>
            <h1>{{$name}} {{$id}} {{$password}}</h1>
            <?php }else { ?>
            <h1>this is my posts.</h1>
            <?php } ?>
@endsection

