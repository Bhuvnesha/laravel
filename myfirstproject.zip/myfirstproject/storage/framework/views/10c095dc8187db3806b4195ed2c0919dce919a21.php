<html>
<head>
	<meta charset="UTF-8">
	<title>Testing Layout</title>
</head>
<body>
	<div class="container">
		<?php echo $__env->yieldContent('content'); ?>

		<?php echo $__env->yieldContent('footer'); ?>
	</div>
	
</body>
</html>