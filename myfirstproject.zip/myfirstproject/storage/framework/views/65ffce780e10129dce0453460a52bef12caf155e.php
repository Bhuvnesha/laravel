<?php $__env->startSection('content'); ?>
<h1>This is test page</h1>
<?php if(count($names) > 0): ?>
	<ul>
		<?php foreach($names as $name): ?>
			<li><?php echo e($name); ?></li>
		<?php endforeach; ?>
	</ul>
<?php endif; ?>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout/app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>