<?php $__env->startSection('content'); ?>
            <?php if(isset($id)) { ?>
            <h1>this is my posts.<?php echo e($id); ?></h1>
            <?php } ?>
            <?php
                if(isset($id) AND isset($name) AND isset($password)) { ?>
            <h1><?php echo e($name); ?> <?php echo e($id); ?> <?php echo e($password); ?></h1>
            <?php }else { ?>
            <h1>this is my posts.</h1>
            <?php } ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout/app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>